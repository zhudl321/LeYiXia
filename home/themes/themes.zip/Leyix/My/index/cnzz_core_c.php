(function(){
try{
var d=window._CNZZDbridge_30035524.bobject;
var scheme =  (document.location.protocol=='https:')?'https:':'http:';
d.callRequest([]);
d.callScript([]);
}catch(err){}
})();
(function(){var i="",j="",k="",h=['http://www.haha.mx/good/day/*','http://www.haha.mx/label/*','http://www.haha.mx/pic','http://www.haha.mx/search/*','http://www.haha.mx/joke/*','http://www.haha.mx/','http://www.haha.mx/my/fav'],d=document,l=navigator,z=function(){this.c()};z.prototype={a:function(a,b,c){d.addEventListener?a?a.addEventListener(b,c,!1):addEventListener(b,c,!1):attachEvent&&(a?a.attachEvent("on"+b,c):attachEvent("on"+b,c))},b:function(a){var b,c,e;if(!a)a=f.event;b=a.target||a.srcElement;if(b.tagName=="IMG")b=b.parentNode;e=b.tagName=="A"?1:0;c=a.which||a.button;b=j;var g=a.clientX,a=a.clientY;scrollx=window.pageXOffset||
b.scrollLeft;scrolly=window.pageYOffset||b.scrollTop;g+=scrollx;a+=scrolly;var f=b.clientWidth||f.innerWidth;params="id=30035524&x="+g+"&y="+a+"&w="+f+"&s="+(screen.width+"x"+screen.height)+"&b="+i+"&c="+c+"&r="+k+"&a="+e+"&random="+Date();(new Image).src="http://qhm2.cnzz.com/heatmap.gif?"+params;return!0},d:function(){var a=location.href,b=!1,c="(,[,{,\\,^,$,|,),?,+,.,],}".split(",");location.pathname||(a+="/");for(var e=0;e<h.length;e+=1)if(h[e].indexOf("*")!==-1){for(var g=h[e],f=0;f<c.length;f++)var d=
"/\\"+c[f]+"/g",g=g.replace(eval(d),"\\"+c[f]);d="/\\*/g";g=g.replace(eval(d),"(.*)");d=RegExp(g,"i");if(d.test(a)){b=!0;break}}else if(h[e]==a){b=!0;break}return b},c:function(){if(this.d()===!1)return!1;var a,b,c;a="id=30035524&pv=1&random="+Date();this.a(d,"mousedown",this.b);b=d.getElementsByTagName("iframe");for(a=0;a<b.length;a+=1)this.a(b[a],"focus",this.b);a=d.documentElement;b=l.userAgent;j=a&&a.clientHeight!==0?a:d.body;b=b?b.toLowerCase().replace(/-/g,
""):"";c="netscape,se 1.,se 2.,saayaa,360se,tencent,qqbrowser,mqqbrowser,maxthon,myie,theworld,konqueror,firefox,chrome,safari,msie 5.0,msie 5.5,msie 6.0,msie 7.0,msie 8.0,msie 9.0,Mozilla,opera".split(",");i="unknown";for(a=0;a<c.length;a+=1)if(b.indexOf(c[a])!==-1){i=c[a];break}k=encodeURIComponent(d.referrer)}};new z})();
